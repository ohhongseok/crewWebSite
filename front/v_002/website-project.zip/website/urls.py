"""website URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
import emsys.views
from django.contrib import admin
from django.urls import path

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', emsys.views.home, name='home'),  # 메인 페이지

    path('introcrewpgone', emsys.views.introduceone, name='intropgone'),  # 동아리 소개페이지
    path('introcrewpgtwo', emsys.views.introducetwo, name='intropgtwo'),  # 동아리 정보공개페이지

    path('swnotice', emsys.views.swnotice, name='notice1'),  # 소프트웨어 공지사항
    path('sw7upnotice', emsys.views.sw7upnotice, name='notice2'),  # 소중사업단 공지사항

    path('crewactivity', emsys.views.crewactivityu, name='crewpic'),  # 동아리 활동(사진)

    path('swarchive', emsys.views.swarchive, name='swarchive'),  # 소웨과 자료
    path('competitionarchive', emsys.views.competitionarchive, name='competition'),  # 공모전 자료

    path('mypage', emsys.views.mypage, name='mypage'),  # 마이페이지
    path('signinup', emsys.views.signinup, name='signinup'),  # 로그인 및 회원가입

    # -------------------[삭제할요소]-------------------------------------
    path('element', emsys.views.element, name='element'),  # 웹페이지 엘리먼트요소
    # -------------------[삭제할요소]-------------------------------------
]
