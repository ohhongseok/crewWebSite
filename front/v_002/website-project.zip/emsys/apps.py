from django.apps import AppConfig


class EmsysConfig(AppConfig):
    name = 'emsys'
