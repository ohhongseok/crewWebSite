from django.shortcuts import render


# Create your views here.
def home(request):
    return render(request, 'emsys/index.html')


def introduceone(request):
    return render(request, 'emsys/introcrewpgone.html')


def introducetwo(request):
    return render(request, 'emsys/introcrewpgtwo.html')


def swnotice(request):
    return render(request, 'emsys/swnotice.html')


def sw7upnotice(request):
    return render(request, 'emsys/sw7upnotice.html')


def crewactivityu(request):
    return render(request, 'emsys/crewactivity.html')


def swarchive(request):
    return render(request, 'emsys/swarchive.html')


def competitionarchive(request):
    return render(request, 'emsys/competionarchive.html')


def mypage(request):
    return render(request, 'emsys/mypage.html')


def signinup(request):
    return render(request, 'emsys/signinup.html')


def element(request):
    return render(request, 'emsys/element.html')